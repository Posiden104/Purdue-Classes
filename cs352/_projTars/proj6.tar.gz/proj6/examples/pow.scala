printInt(intPow(3, 12));
0
