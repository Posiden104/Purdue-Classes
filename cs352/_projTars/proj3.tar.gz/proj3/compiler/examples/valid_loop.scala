var x = 2;
var y = 0;
while (y < 3) {
  val dummy = x = x * x;
  y = y + 1
};
x
