if (2 > 4) 1 + 4 else 4
