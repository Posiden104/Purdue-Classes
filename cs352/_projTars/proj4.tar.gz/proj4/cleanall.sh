#!/bin/bash

find . -name target -exec rm -rf {} \; > /dev/null
