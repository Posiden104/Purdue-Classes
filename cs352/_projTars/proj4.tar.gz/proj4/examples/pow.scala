printInt(intPow(3, 12))
