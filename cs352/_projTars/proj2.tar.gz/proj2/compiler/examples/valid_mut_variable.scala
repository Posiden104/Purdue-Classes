var x = 0; x = (x = x + 2) - 1
