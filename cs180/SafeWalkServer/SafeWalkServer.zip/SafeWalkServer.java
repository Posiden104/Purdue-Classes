import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;

/**
 * Project 5
 * @author Joel Van Auken, jvanauke, 801
 */

public class SafeWalkServer implements Runnable {

	private ServerSocket ss;

	private ArrayList<Request> requests; // now holds clients as well

	private int match; // used to get index of matched client
	private boolean clean; // used to determine if it needs to clean the client
	boolean running = true; // used to exit server

	private String[] validLocations = new String[] { "CL50", "EE", "LWSN", "PMU", "PUSH", "*" };

	public class Request {
		String name, TO, FROM;
		int TYPE;
		Socket client;

		Request(Socket client, String name, String FROM, String TO, int TYPE) {
			this.name = name;
			this.TO = TO;
			this.FROM = FROM;
			this.TYPE = TYPE;
			this.client = client;
		}

		public String print() {
			String ret;
			ret = String.format("%s,%s,%s,%d", name, FROM, TO, TYPE);
			return ret;
		}
		public String print2() {
			String ret;
			ret = String.format("%s, %s, %s, %d", name, FROM, TO, TYPE);
			return ret;
		}
	}

	/**
	 * Construct the server, set up the socket.
	 * 
	 * @throws SocketException
	 *             if the socket or port cannot be obtained properly.
	 * @throws IOException
	 *             if the port cannot be reused.
	 */
	public SafeWalkServer(int port) throws SocketException, IOException {
		ss = new ServerSocket(port);
		System.out.printf("Server Socket started on port %d\n", getLocalPort());
		requests = new ArrayList<Request>();
	}

	/**
	 * Construct the server and let the system allocate it a port.
	 * 
	 * @throws SocketException
	 *             if the socket or port cannot be obtained properly.
	 * @throws IOException
	 *             if the port cannot be reused.
	 */
	public SafeWalkServer() throws SocketException, IOException {
		ss = new ServerSocket(0);
		System.out.printf("\nServer Socket started on port %d\n", getLocalPort());
		requests = new ArrayList<Request>();
	}

	/**
	 * Start a loop to accept incoming connections.
	 * 
	 */
	public void run() {
		System.out.println("Commence ServerSocket...");

		try {
			while (running) {
				clean = false;
				System.out.println("Ready!");
				Socket client = ss.accept();
				PrintWriter pw = new PrintWriter(client.getOutputStream());
				pw.flush();
				BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));

				String line = null;

				System.out.println("Starting loop...\n");
				line = in.readLine();
				System.out.printf("read: %s\n", line);

				String response;
				response = handleUser(line, client);
				if (response != "") {
					pw.write(response);
					pw.flush();
					if (clean) {
						cleanUp(client);
					}
				}
			}

			System.out.println("Loop exited");

			cleanUp(ss);
		} catch (Exception e) {
			running = false;
		}
	}

	public String handleUser(String line, Socket user) throws IOException {
		if (line.charAt(0) == ':') {
			return handleCommand(line, user);
		} else {
			return handleRequest(line, user);
		}
	}

	public String handleCommand(String command, Socket client) throws IOException {
		System.out.println("command recognized");
		switch (command) {
		case ":LIST_PENDING_REQUESTS":
			return listRequests();
		case ":RESET":
			return reset();
		case ":SHUTDOWN":
			running = false;
			return reset();
		}
		System.out.println("invalid command");
		return "ERROR: invalid request\n";
	}

	public String handleRequest(String request, Socket client) throws IOException {
		System.out.println("request recognized");
		Request r;
		String[] args = request.split(",");
		if (args.length == 4) {
			if (checkValidity(args)) {
				r = new Request(client, args[0], args[1], args[2], type(args[3]));

				match = -1;

				if ((match = checkMatch(r)) != -1) {
					send(requests.get(match).client, String.format("RESPONSE: %s", r.print()));
					String ret = String.format("RESPONSE: %s\n", requests.get(match).print());
					remove(match);
					clean = true;
					return ret;
				} else {
					requests.add(r);
					clean = false;
					return "";
				}
			}
		}
		clean = true;
		return "ERROR: invalid request\n";

	}

	public int checkMatch(Request r) {
		for (int i = 0; i < requests.size(); i++) {
			Request r1 = requests.get(i);
			// if either request is a volunteer
			if (r1.TO.equals(validLocations[5]) || r.TO.equals(validLocations[5])) {
				// if !(both requests are volunteers)
				if (!(r1.TO.equals(validLocations[5]) && r.TO.equals(validLocations[5]))) {
					// if the destinations are the same
					if (r1.FROM.equals(r.FROM)) {
						return i;
					}
				}
				// if the origins and destinations are the same
			} else if (r1.TO.equals(r.TO) && r1.FROM.equals(r.FROM)) {
				return i;
			}
		}
		return -1;
	}

	public boolean checkValidity(String[] args) {
		if (args[1].equals(args[2]))
			return false;

		if (args[1].equals(validLocations[5]))
			return false;

		int type = type(args[3]);

		if (type > 2 || type < 0)
			return false;

		int flag = 0;
		for (int i = 0; i < validLocations.length; i++) {
			if (args[1].equals(validLocations[i])) {
				flag++;
			}

			if (args[2].equals(validLocations[i])) {
				flag++;
			}
		}

		if (flag != 2)
			return false;

		return true;
	}

	public int type(String arg) {
		int type;
		try {
			type = Integer.parseInt(arg.substring(0, 1));
		} catch (NumberFormatException e) {
			try {
				type = Integer.parseInt(arg.substring(0, 2));
			} catch (NumberFormatException e2) {
				return -1;
			}
		}
		return type;
	}

	// list requests
	public String listRequests() {
		String ret = "[";
		for (int i = 0; i < requests.size(); i++) {
			ret = ret + String.format("[%s]", requests.get(i).print2());
			if (i != requests.size() - 1) {
				ret = ret + ", ";
			}
		}
		ret = ret + "]\n";
		 clean = true;
		return ret;
	}

	// reset + send error to clients
	public String reset() throws IOException {
		while (requests.size() > 0) {
			Socket c = requests.get(0).client;
			send(c, "ERROR: connection reset\n");
			requests.remove(0);
			cleanUp(c);
		}
		clean = true;
		return "RESPONSE: success\n";
	}

	/**
	 * Return the port number on which the server is listening.
	 */
	public int getLocalPort() {
		return ss.getLocalPort();
	}

	public void send(Socket client, String msg) throws IOException {
		PrintWriter pw = new PrintWriter(client.getOutputStream());
		pw.flush();
		pw.printf(msg);
		pw.flush();
	}

	public void remove(int i) throws IOException {
		Socket client = requests.get(i).client;
		requests.remove(i);
		cleanUp(client);
	}

	public void cleanUp(Socket s) throws IOException {
		System.out.println("Cleaned " + s);
		s.shutdownInput();
		s.shutdownOutput();
		s.close();
	}

	public void cleanUp(ServerSocket ss) throws IOException {
		ss.close();
		System.out.println("ServerSocket cleaned up");
		running = false;
	}

	public static void main(String[] args) throws SocketException, IOException {
		SafeWalkServer sws = new SafeWalkServer(4242);
		sws.run();
		System.out.println("End of program");
	}

}
