
#include <stdio.h>
#include <stdlib.h>

#define MAXSTACK 50

int
main(int argc,  char **argv)
{

}

