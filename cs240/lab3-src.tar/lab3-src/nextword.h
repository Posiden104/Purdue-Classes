
#include <stdio.h>

// It returns the next word from stdin.
// If there are no more more words it returns NULL. 
extern char * nextword(FILE * fd);

