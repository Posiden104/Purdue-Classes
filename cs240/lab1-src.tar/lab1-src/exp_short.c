#include <stdio.h>
#include "add.h"

int main() {
	printf("2 + 2 = %d\n", add(2,2));
}
